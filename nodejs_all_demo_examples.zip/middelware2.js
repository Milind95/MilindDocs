var express = require("express");
var  app = express(); 

app.use(function (req, res, next) {
   console.log ("Start");
   next();
});
      
app.get("/", function(req,res,next)
{
    res.send("<h1> middle called </h1>");
    next();
});

app.use("/",function (req, res, next) {
   console.log ("end");
});
      
app.listen(3000);
