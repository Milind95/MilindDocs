var fs = require("fs");


var readerStream = fs.createReadStream("input.txt");
var writterStream = fs.createWriteStream("output.txt");

//pipe the read and write operations
//read from input.txt and write to output.txt

readerStream.pipe(writterStream);
console.log ("Program ended");
