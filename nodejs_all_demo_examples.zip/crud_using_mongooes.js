



var mongoose = require('mongoose');

var url = "mongodb://localhost:27017/mydb";

mongoose.connect(url, function(err,result){
   if(err) 
      console.log("Error in connection" + err);
   else
      console.log("Connection succesful");
}
);

// create schema instance  
var EmployeeSchema = new mongoose.Schema({
  name: String,
  address: String,
  position: String,
  salary: Number,
  updated_at: { type: Date, default: Date.now },
});

// Employee model
              
var Employee = mongoose.model("empmgmt",EmployeeSchema);

var employee = new Employee();
 //set values 
 employee.name ="Anil";
 employee.address ="Mumbai";
 employee.position = "Teacher";
 employee.salary = 3000;

// save employee object created from Employee model into database


employee.save(function(err) {
    if(err) {
      console.log(err);
    } else {
      console.log("Successfully created an employee.");
      //console.log("Employee name"+employee._id);
    }
 });

// querying databse

Employee.find({"name":'Anil'}).exec(function (err, employees) {
    if (err) {
      console.log("Error:", err);
    }
    else {
      console.log(employees);
    }
});

//delete record
/*
Employee.remove({"name":'Anil'}, function(err) {
    if(err) {
      console.log(err);
    }
    else {
      console.log("Employee deleted!");
   }
});
*/
// modify/updated_at


Employee.findOneAndUpdate({"name":'Anil'}, { $set: { "salary": 5000}}, function (err, employee) {
    if (err) {
      console.log(err);
    }
    console.log(" record updated");
  });







