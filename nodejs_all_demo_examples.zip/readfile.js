//asynchronious file read
var fs= require("fs");

setInterval(function(){
  console.log("Hey, 1 mili second completed");
  }, 1000
);

var mycallback = function( err, data){

    if(err)
    {
        return console.error(err);
    }
    console.log("asynchronious read " +data.toString() );

}

fs.readFile("filepath", mycallback);

/*

var data=fs.readFileSync("input.txt");
console.log(data.toString());




Assignment 1:
using asynchronious calls, implement 
copy("input.txt","output.txt")
//output expected - it should create output.txt file with the contents of input.txt

*/