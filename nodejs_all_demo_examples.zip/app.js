var express = require("express");
var app= express();
var handleRequest = function( req, res)
{
    var param = req.params.name;
    var ageparam = req.params.age;
    res.send("<h1> Hello " + param + " and your age is " +ageparam +"</h1>");
}
app.get("/hello/:name/:age", handleRequest);
app.get("/about", function( req, res)
{
    res.send("<h1>Hello- This is for  about request  </h1>")
}
);
app.get("*", function( req, res)
{
    res.send("No End Point Defined for this URL");
}
);
app.listen(8080); 