
var express = require("express");
var cookieParser = require("cookie-parser");
var session = require("express-session");

var app= express();

app.use(cookieParser());
app.use(session({secret:"confidential"}));

app.get("/session", function(req,res)
{
    if(req.session.page_view) {
        console.log("Cookies :"+ req.cookies);
        req.session.page_view++;
        res.send("You visited this page"+req.session.page_view +"times");
       } else {
       req.session.page_view=1; 
       console.log("Cookies :"+ req.cookies);
       res.send("First time visit"); 
     }
});
app.listen(3000);

