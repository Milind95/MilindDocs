// how to create buffer
// 3 ways
//var buf= new Buffer(10); //uninitialized buffer
//var buf = new Buffer([10,20,30,40]);
var buf = new Buffer("Node Js Learning",'utf8'); //creating buffer using string
// buffer is global object -->

//how to write in the buffer
var targetbuf = new Buffer(10);

console.log(buf.toString());

//var buf1= buf.slice(2,6);
//console.log(buf1.toString());

buf.copy(targetbuf,0,2,6);
console.log(targetbuf.toString());