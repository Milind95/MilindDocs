var bcrypt = require('bcryptjs');

/*
//Synchronous Approach 
var hash = bcrypt.hashSync("Karthik",bcrypt.genSaltSync(10));

console.log(hash);

//checking match
var valid= bcrypt.compareSync("Anil", hash); 
console.log (valid);

*/

//Asynchronous Approach
bcrypt.hash("Karthik", bcrypt.genSaltSync(10), function(err, hash) {
bcrypt.compare("Karthik1", hash, function(err, res) {
	console.log(res);
});
});

