var express = require("express");
var bodyParser = require("body-parser");

var app = express();
var movies = [{
    id: 101, name: "movie1", year:2001
},{
     id: 102, name: "movie2", year:2002
},{
     id: 103, name: "movie3", year:2003
}];

app.use(bodyParser.urlencoded({extended: true}));

app.use (bodyParser.json())

app.get("/movies", function (req, res)
{
    res.json(movies);
})

app.get("/movies/:id", function (req, res)
{
   var currMovie = movies.filter(
       function(movie) {
           console.log("movie id=" + movie.id);
           console.log("movie id=" + req.params.id);
           if (movie.id == req.params.id){
               return true;
           }
       }
   );
   if (currMovie.length ==1){
       res.json(currMovie[0]);
   } else {
       res.status(404);
       res.json({"message": "Not found"});
   }

})

//insert or add
app.post("/movies", function (req, res)
{
    console.log(req.body);
    var movie = { };
    movie.id= req.body.id;
    movie.name= req.body.name;
    movie.year= req.body.year;
    console.log(movie);
    movies.push(movie);
    res.json( {message:" new movie added"});
})

app.listen(3000);

