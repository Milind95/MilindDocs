/*

types -

1 Readable
2 Writable
3 Duplex
4 Transform

Events 
1) Data - this event is fired when there is data available to read.
2) End - no data available to read.
3) Error - any error while reading or writting data.
4) Finish -all the data flushed to underlying system
*/

// Reading from stream

var fs = require("fs");
var data ="";
var readerStream = fs.createReadStream("input.txt");
readerStream.setEncoding('UTF8');
//handle the stream Events
readerStream.on("data",function (chunk){
data +=chunk;
console.log("***********");
}
);

readerStream.on("end",function (){
console.log(data);
}
);

readerStream.on("error",function (err){
console.log(err.stack);
}
);


setInterval(function(){
  console.log("Hey, 1 mili second completed");
  }, 1000
);


console.log("Program ended");





