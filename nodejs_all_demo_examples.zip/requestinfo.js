var express = require("express");

var app= express();

app.get("/showinfo", function(req,res)
{
   res.send("host:"+ req.host +" ip =:" + req.ip + "url="+ req.url)
});

app.listen(3000);