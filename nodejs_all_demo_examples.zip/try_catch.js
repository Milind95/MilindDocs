
try{
const a=5;
c= a+b;
} catch( err )
{   console.log("The error is :");
    console.log(err);
}