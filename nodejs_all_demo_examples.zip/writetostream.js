/*

types -

1 Readable
2 Writable
3 Duplex
4 Transform

Events 
1) Data - this event is fired when there is data available to read.
2) End - no data available to read.
3) Error - any error while reading or writting data.
4) Finish -all the data flushed to underlying system
*/

// Writting to file using streams

var fs = require("fs");
var data ="This is text line i want in input1.txt file";
var writterStream = fs.createWriteStream("input1.txt");
writterStream.write(data);
//handle the stream Events
writterStream.on("finish",function (){
console.log("write completed");
}
);

writterStream.on("error",function (err){
console.log(err.stack);
}
);
console.log("Program ended");





